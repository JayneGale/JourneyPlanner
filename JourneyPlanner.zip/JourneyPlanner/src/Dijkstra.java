public class Dijkstra {
    //pseudocode
//    Add the starting point to the prioroty Queue(<a, null, 0>)
//        start by making a priority queue weighted by cost, g.
//        Nodes are <node, prev, cost>. Set all the unvisited.ReadDataFiles
//    Visited List  of visited, and  priority queue of unvisited;
//    Take a off the priorotqueue and isit it. Add all its unvisited neightbouts and costs to the Q
//            Q = <c,a,costac><b,a,costab, d,a,costad>
//    order by cost and remove the loswet cost child

}
