import java.util.List;

public class Node {
    public String stop_id;
    public List<Edge> adjListIncoming;
    public List<Edge> adjListOutgoing;
    //attributes could be eg: time, distance, start and end nodes

}
